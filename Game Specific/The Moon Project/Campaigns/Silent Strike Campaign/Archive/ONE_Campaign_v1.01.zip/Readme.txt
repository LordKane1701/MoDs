=======================================================
		Ciche uderzenie - A soft blow
=======================================================

Nazwa : 		Ciche uderzenie
Nazwa pliku :	ONE_Campaign_v1.01.wd
Wersja : 		1.01
Gra : 		Earth 2150 : The Moon Project
Typ : 		Kampania
Data wydania :	09.07.2003
Autor :
- mapy :		ONE
- skrypty :		ONE

Opis : 		Jest to dodatkowa kampania do "Earth 2150 : The Moon Project" , przeznaczona dla UCS
		Zawiera 20 ca�kowicie nowych misji.
G��wny tester :	Rosic
Drugi tester :	PWL

Znane b��dy :	- Usuni�te w wersji 1.01 :
		-  Kiedy misje : Filipiny i G�ry kaskadowe przechodzi�o si� w kolejno�ci : najpierw G�ry kaskadowe a potem Filipiny  nie 			   pojawia�a si� nast�pna misja

=======================================================

Czas pracy nad kampani� : ok. 4 miesi�ce
U�ywane programy :
- notatnik
- WDCreator
- LangC
- EarthCMP
- Edytor Map (wbudowany w Eartha )

=======================================================

Instalacja : skopiuj plik 'ONE_Campaign_v1.01.wd' do katalogu WDFiles

=======================================================







ENGLISH

================================================== =====
A soft blow
================================================== =====

Name: A silent strike
File name: ONE_Campaign_v1.01.wd
Version: 1.01
Game: Earth 2150: The Moon Project
Type: Campaign
Release Date: 07/09/2003
Author:
- maps: ONE
- scripts: ONE

Description: This is an additional campaign for "Earth 2150: The Moon Project" for UCS
Includes 20 completely new missions.
Lead Subject: Rosic
Second tester: PWL

Known bugs: - Fixed in v1.01:
- When the Philippines and Cascading Mountains missions were passed in order: Cascade Mountains first, then Philippines, no next mission appeared

================================================== =====

Working time on the campaign: approx. 4 months
Programs used:
- notebook
- WDCreator
- LangC
- EarthCMP
- Map editor (built into Eartha)

================================================== =====

Installation: copy the file 'ONE_Campaign_v1.01.wd' to the WDFiles directory

================================================== =====

================================================== =====
Silent Strike - A soft blow
================================================== =====

Name: Silent strike
File name: ONE_Campaign_v1.01.wd
Version: 1.01
Game: Earth 2150: The Moon Project
Type: Campaign
Release Date: 07/09/2003 - 4/22/2023 (English)
Author:
- maps: ONE
- scripts: ONE

Description: This is an additional campaign for "Earth 2150: The Moon Project" for UCS
Includes 20 completely new missions.
Lead Subject: Rosic
Second tester: PWL
English translation: JustDiego
Prototypes fix: Guardian

Known bugs: - Fixed in v1.01:
- When the Philippines and Cascading Mountains missions were passed in order: Cascade Mountains first, then Philippines, no next mission appeared
- Prototypes no longer crash the game when reaching main base undeground

================================================== =====

Working time on the campaign: approx. 4 months
Programs used:
- notebook
- WDCreator
- LangC
- EarthCMP
- Map editor (built into Eartha)

================================================== =====

Installation: copy the files 'ONE_Campaign_v1.01.wd' and 'ONE_CampaignPath_v1.01.wd' to the WDFiles directory
IMPORTANT: Backup into a zip and delete your older WD files if you still have them (to avoid problems, TMP still can read your old files even if you rename or move them)

================================================== =====
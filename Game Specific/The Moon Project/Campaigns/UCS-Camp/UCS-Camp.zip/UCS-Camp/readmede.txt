Installation:
 
ucs-maps.zip im TMP Ordner Levels entpacken. Es sollten dann 
Dateien wie !410.lnd, usw. vorhanden sein. Fuer ucs-scripts.zip einen 
Ordner Scripts anlegen, darin die scripte entpacken. Bei mir 
existiert z.B. der Ordner
 
 ..\Topware\The Moon Project\Scripts\Campaigns\UCS\missions
 
 Ein geaendertes AI Platoon script gibts in
 
 ..\Topware\The Moon Project\Scripts\Units\Ai
 
 Sollte bei Dir dann aehnlich aussehen ;-)
 
Um das Ganze zu deinstallieren einfach den Ordner Scripts wieder loeschen,  
in Levels alle !4xx.lnd, !4xx.mis, !UCSBaseUCS*.* Dateien loeschen ...

*************************************************************************************
Hinweis: Vor Multiplayer-Spielen im Inet bitte den Ordner Scripts umbenennen oder 
loeschen. Die Scripte werden sonst vor Spielstart zwischen den Rechnern ausgetauscht
*************************************************************************************

Die Scripte laufen nur unter TMP (nicht unter LS, Earth)

* Schwierigkeitsstufe: Ist komplett auf 'schwer' ausgelegt und 
  getestet. Zu Beginn irgendwo zwischen den Original-Missionen 
  und LS, am Ende teilweise hoeher als LS.

Features: 

* ueberarbeitete Maps, Forschung, usw., an den ersten Missionen
  wurde am wenigsten geaendert, das steigert sich in alpha, beta, 
  gamma, ..., die letzte Mission 'Exekution' ist im Grossen und
  Ganzen neu, *wer* exekutiert wird ist noch nicht sicher ;-)
  Zumindest hab ich meine gesamte bisherige TMP Erfahrung
  einfliessen lassen und dabei auch immer an Blackhawk gedacht ...

  "als erfahrener online-player brauchste f�r egal wieviele max 1h.,
   wenn die armee mal losgefahren ist wars das f�r die AI"

* Rohstoffe: letztendlich kann man jede Mission spaetestens
  dann gewinnen, wenn die KI alle Resourcen abgebaut hat und
  pleite ist. Es werden an keiner Stelle scriptmaessig credits 
  zugefuehrt (ausser Startgeld zur Umruestung von Gebaueden ...)

* optimierte KI Steuerung (geballte Angriffe, dazwischen ausreichend 
  Zeit zur Regeneration, Vermeidung von 1er-Platoons und aehnlichem)

* 99,95 % der Kampfeinheiten werden tatsaechlich produziert. Jede 
  zerstoerte Waffenfabrik ist also ein kleiner Schritt zum Sieg ...

* + vieles mehr, z.B. ausgiebiger Tunnelkampf, eine neue 
  Grizzly-Modifikation (nein kein Banner+Banner Grizzly ;-), usw. ..

Tipps:

* Die Qualitaet der KI-Angriffe haengt davon ab, an welcher Stelle 
  der Spieler das erste Kraftwerk errichtet. Ich hab versucht, 
  moegliche Problemstellen fuer die KI (hohe Berge, usw.) zu 
  entschaerfen, garantieren kann ich natuerlich fuer nichts ;-)

* UCS Florida: Am Schluss werden wie schon in den Originalmissionen
  alle zusaetzlich gefoerderten Rohstoffe nicht fuer weitere Missionen
  gutgeschrieben (50000 reichen aus) ... 

* Landezone: Defensivverhalten der KI verbessert

* Mailman: nahezu unveraendert

* Alpha: Vor Alpha unbedingt auf Spielstufe 'schwer' stellen, sonst
  entgeht einem einiges. Zu Beginn nach strategischen Gesichtspunkten 
  bauen, die Einheiten laufend mit einer repture Einheit auf den neusten 
  Stand bringen. Wenn erst mal alle Einheiten mit einem 600er Schild 
  ausgeruestet sind, ist das Schlimmste ueberstanden. Das KI-Verhalten 
  entspricht in etwa dem von 'skirmish'

* Pacificum: nahezu unveraendert

* Beta: auch hier muss man sich zu Beginn ueber die richtige
  Vorgehensweise Gedanken machen, sonst sind die Grizzlies 
  moeglicherweise weg. Offensiv- und Defensivverhalten der 
  KI verbessert.

* Death Canyon: jetzt deutlich schwerer

* Gamma: Einige Forschungen werden waehrend der Mission 
  freigeschaltet. Gut ausgebaute Stellungen notwendig, die
  KI macht richtig Druck. 

* Hollow Man: nahezu unveraendert

* Delta: Gute Luftwaffe notwendig, das Zusammenspiel zwischen
  Dragon SR und B muss klappen. Es ist von Vorteil, wenn alle
  Dragons in den vorherigen Missionen schon ca. 4 Erfahrungspunkte
  gesammelt haben, also mind. HP 1050 aufweisen.

* Exekution: Sehr gut ausgebaute Stellungen notwendig, vor allem Luftabwehr.
  Erstes Ziel ist die Eroberung des ersten Tunnelabschnitts und die 
  Zerstoerung der LC-seitigen Tunneleingaenge ...


               Wuensche viel Spass

               Cayenne  
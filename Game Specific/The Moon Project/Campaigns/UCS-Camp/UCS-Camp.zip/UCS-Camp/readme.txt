Installation:
 
Unzip ucs-maps.zip in the TMP Levels folder. There should then be 
files like !410.lnd, etc. should be present. For ucs-scripts.zip create a folder called 
folder Scripts, unzip the scripts into it. With me 
there is e.g. the folder
 
 ..\Topware\The Moon Project\Scripts\Campaigns\UCS\missions
 
 A modified AI Platoon script can be found in
 
 ..\Topware\The Moon Project\Scripts\Units\Ai
 
 Should look similar for you ;-)
 
To uninstall the whole thing just delete the folder Scripts again,  
in Levels delete all !4xx.lnd, !4xx.mis, !UCSBaseUCS*.* files ...

*************************************************************************************
Note: Before playing multiplayer games on the net, please rename or delete the Scripts folder. 
delete. Otherwise the scripts will be exchanged between the computers before the game starts.
*************************************************************************************

The scripts only run under TMP (not under LS, Earth).

* Difficulty level: Is completely designed for 'difficult' and 
  tested. At the beginning somewhere between the original missions 
  and LS, at the end partly higher than LS.

Features: 

* reworked maps, research, etc., the first missions have been
  least changed, this increases in alpha, beta, 
  gamma, ..., the last mission 'Execution' is by and large new.
  new, *who* will be executed is not sure yet ;-)
  At least I've used all my TMP experience so far and
  and I always thought of Blackhawk ...

  "as an experienced online-player you need max 1h for no matter how many..,
   once the army has set off, that's it for the AI".

* raw materials: in the end you can win every mission at the latest
  mission at the latest, when the AI has mined all resources and is
  is broke. At no point are credits added script-wise (except starting 
  (except for starting money to re-equip buildings ...)

* optimised AI control (concentrated attacks, enough time for regeneration in between, avoiding 
  time for regeneration, avoidance of 1s-platoons and the like)

* 99,95 % of the combat units are actually produced. Each 
  destroyed weapons factory is a small step to victory ...

* + much more, e.g. extensive tunnel combat, a new grizzly modification 
  Grizzly modification (no no banner+banner grizzly ;-), etc. ...

Tips:

* The quality of the AI attacks depends on where the player 
  the player builds the first power plant. I have tried, 
  possible problem areas for the AI (high mountains, etc.). 
  but of course I can't guarantee anything ;-)

* UCS Florida: At the end of the mission, as in the original missions
  all additional resources will not be credited for further missions (50000 is
  (50000 are enough) ... 

* Landing zone: Defensive behaviour of the AI improved

* Mailman: almost unchanged

* Alpha: Before alpha, be sure to set the game level to 'difficult', otherwise you will
  you will miss out on a lot. At the beginning, build according to strategic 
  build from a strategic point of view, constantly update the units with a repture unit. 
  with a repture unit. Once all units have been equipped with a 600 shield 
  shield, the worst is over. The AI behaviour 
  is similar to that of 'skirmish'.

* Pacificum: almost unchanged

* Beta: also here you have to think about the right approach at the beginning
  about the right approach, otherwise the grizzlies might be 
  might be gone. Offensive and defensive behaviour of the 
  AI improved.

* Death Canyon: now much harder

* Gamma: Some researches are unlocked during the mission. 
  unlocked during the mission. Well developed positions necessary, the
  AI makes real pressure. 

* Hollow Man: almost unchanged.

* Delta: Good airforce necessary, the interaction between
  Dragon SR and B must work. It is an advantage if all
  Dragons have already gained about 4 experience points in the previous missions.
  in the previous missions, i.e. have at least HP 1050.

* Execution: Very well developed positions are necessary, especially air defence.
  First objective is the conquest of the first tunnel section and the 
  destruction of the LC-side tunnel entrances ...


               Have fun

               Cayenne  
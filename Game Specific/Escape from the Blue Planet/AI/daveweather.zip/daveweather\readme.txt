Desw.wd
WEATHER MOD BY GERMAN SCRIPTER -- BYTE
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
To Install
=======

Place the .wd file in the "WDFiles" folder in the Earth 2150 directory.
This is usually located C:\Program Files\SSI\Earth 2150\ or C:\SSI\Earth 2150\

Run the game!

The weather script runs the chosen weather type across the map.


-Ice Man
http://www.earth-orbiter.com

=====================================================
VISIT OUR FORUM TO DISCUSS EARTH 2150 ISSUES, TACTICS, PROBLEMS AND MORE
HTTP://WWW.EARTH-ORBITER.COM/FORUM.HTML
